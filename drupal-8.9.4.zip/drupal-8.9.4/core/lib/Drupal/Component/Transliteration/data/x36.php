<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zuo', 'yi', 'ci', NULL, 'leng', 'xian', 'tai', 'rong', 'yi', 'zhi', 'xi', 'xian', 'ju', 'ji', 'han', NULL,
  0x10 => 'pao', 'li', NULL, 'lan', 'sai', 'han', 'yan', 'qu', NULL, 'yan', 'han', 'kan', 'chi', 'nie', 'huo', NULL,
  0x20 => 'bi', 'xia', 'weng', 'xuan', 'wan', 'you', 'qin', 'xu', 'nie', 'bi', 'hao', 'jing', 'ao', 'ao', NULL, NULL,
  0x30 => 'zhen', 'tan', 'ju', NULL, 'zuo', 'bu', 'jie', 'ai', 'zang', 'ci', 'fa', NULL, NULL, NULL, NULL, 'nie',
  0x40 => 'liu', 'mei', 'dui', 'bang', 'bi', 'bao', NULL, 'chu', 'xia', 'tian', 'chang', NULL, NULL, 'duo', 'wei', 'fu',
  0x50 => 'duo', 'yu', 'ye', 'kui', 'wei', 'kuai', NULL, 'wei', 'yao', 'long', 'xing', 'zhuan', 'chi', 'xie', 'nie', 'lang',
  0x60 => 'yi', 'zong', 'man', 'zhang', 'xia', 'gun', 'xie', NULL, 'ji', 'liao', 'yi', 'ji', 'yin', NULL, 'da', 'yi',
  0x70 => 'xie', 'hao', 'yong', 'kan', 'chan', 'tai', 'tang', 'zhi', 'bao', 'meng', 'kui', 'chan', 'lei', NULL, 'xi', NULL,
  0x80 => 'xi', 'qiao', 'nang', 'yun', NULL, 'long', 'fu', 'zong', NULL, 'gu', 'kai', 'diao', 'hua', 'kui', NULL, 'gao',
  0x90 => 'tao', NULL, 'shan', 'lai', 'nie', 'fu', 'gao', 'qie', 'ban', 'jia', 'kong', 'xi', 'yu', 'zhui', 'shen', 'chuo',
  0xA0 => 'xiao', 'ji', 'nu', 'xiao', 'yi', 'yu', 'yi', 'yan', 'shen', 'ran', 'hao', 'sa', 'jun', 'you', NULL, 'xin',
  0xB0 => 'pei', 'qiu', 'chan', NULL, 'bu', 'dong', 'si', 'er', NULL, 'mao', 'yun', 'ji', NULL, 'qiao', 'xiong', 'pao',
  0xC0 => 'chu', 'peng', 'nuo', 'jie', 'yi', 'er', 'duo', NULL, NULL, NULL, 'duo', NULL, NULL, 'qie', 'lu', 'qiu',
  0xD0 => 'sou', 'can', 'dou', 'xi', 'feng', 'yi', 'suo', 'qie', 'po', 'xin', 'tong', 'xin', 'you', 'bei', 'long', NULL,
  0xE0 => NULL, NULL, NULL, 'yun', 'li', 'ta', 'lan', 'man', 'qiang', 'zhou', 'yan', 'xi', 'lu', 'xi', 'sao', 'fan',
  0xF0 => NULL, 'wei', 'fa', 'yi', 'nao', 'cheng', 'tan', 'ji', 'shu', 'pian', 'an', 'kua', 'cha', NULL, 'xian', 'zhi',
];
